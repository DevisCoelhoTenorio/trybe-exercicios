const PatientController = require('./Patient.controller');

module.exports = {
    PatientController,
};