const PatientService = require('./Patient.service');

module.exports = {
    PatientService,
};