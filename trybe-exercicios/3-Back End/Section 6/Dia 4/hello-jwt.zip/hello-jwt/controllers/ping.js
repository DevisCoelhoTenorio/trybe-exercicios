module.exports = (_req, res) => {
  res.status(200).json({ message: 'Pong!' });
};
