const topSecret = async (_req, res) => {
    // const teste = req.payload;
    // console.log(teste);
    console.log(res.locals.payload);
    if (res.locals.payload.admin) {
        return res.status(200).json({ message: 'parparaprara foi!' });
    }
    return res.status(666).json({ message: 'no kEY OK Bro' });
};

module.exports = topSecret;
