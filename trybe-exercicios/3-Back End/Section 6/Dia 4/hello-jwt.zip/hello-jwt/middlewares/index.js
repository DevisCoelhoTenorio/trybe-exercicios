const error = require('./error');

module.exports = {
  error,
};
