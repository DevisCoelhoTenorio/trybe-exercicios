const { authTokenValidation } = require('../utils/JWT');

const authMiddleware = async (req, res, next) => {
    const token = req.headers.authorization;
    console.log('token', token);
    const payload = await authTokenValidation(token);

    if (!payload) {
        const error = new Error('error na leitura do token');
        error.status = 401;
        throw error;
    }
    res.locals.payload = payload;
    next();
};

module.exports = authMiddleware;